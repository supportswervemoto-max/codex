import bpy,json
from pathlib import Path
r=Path('/workspace/dont-drop-it-blender');result={}
for name in ['OldPickup','Sofa','Fridge','GiantDuck']:
 bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.fbx(filepath=str(r/(name+'.fbx')))
 meshes=[o for o in bpy.context.scene.objects if o.type=='MESH'];assert meshes
 assert all(len(o.data.vertices)>0 for o in meshes)
 result[name]={'meshObjects':len(meshes),'triangles':sum(len(p.vertices)-2 for o in meshes for p in o.data.polygons),'reimportPassed':True}
(r/'export-validation.json').write_text(json.dumps(result,indent=2));print(result)
