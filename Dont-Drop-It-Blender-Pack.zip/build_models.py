import bpy, math, json
from pathlib import Path
from mathutils import Vector
out=Path('/workspace/dont-drop-it-blender')
bpy.ops.wm.read_factory_settings(use_empty=True)
def mat(n,c,metal=0,rough=.5):
 m=bpy.data.materials.new(n);m.diffuse_color=(*c,1);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*c,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough;return m
paint=mat('Burnt orange enamel',(.64,.12,.045),.35,.3);black=mat('Rubber',(.025,.03,.035),0,.8);chrome=mat('Brushed steel',(.48,.54,.58),.8,.3);glass=mat('Smoked blue glass',(.065,.17,.23),.45,.18);fabric=mat('Ocean upholstery',(.055,.24,.4),0,.9);yellow=mat('Duck vinyl',(.98,.65,.025),0,.28);orange=mat('Beak',(.94,.23,.02));white=mat('Ivory',(.86,.9,.86));mint=mat('Mint enamel',(.28,.67,.52),.25,.3)
def finish(o,n,m):
 o.name=n;o.data.materials.append(m);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return o
def box(n,p,s,m,b=.08):
 bpy.ops.mesh.primitive_cube_add(size=1,location=p);o=bpy.context.object;o.scale=s;finish(o,n,m)
 if b:
  mod=o.modifiers.new('Manufactured edges','BEVEL');mod.width=b;mod.segments=2;bpy.context.view_layer.objects.active=o;bpy.ops.object.modifier_apply(modifier=mod.name)
 return o
def ball(n,p,s,m):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=20,ring_count=12,location=p);o=bpy.context.object;o.scale=s;finish(o,n,m)
 for f in o.data.polygons:f.use_smooth=True
 return o
def cyl(n,p,r,d,m):
 bpy.ops.mesh.primitive_cylinder_add(vertices=24,radius=r,depth=d,location=p,rotation=(0,math.pi/2,0));o=finish(bpy.context.object,n,m)
 return o
assets={}
def begin():return set(bpy.context.scene.objects)
def end(n,old):assets[n]=list(set(bpy.context.scene.objects)-old)
a=begin()
box('Frame',(0,0,1.9),(6.9,16.8,.55),black)
box('Hood',(0,-7.8,3.1),(7.3,3.5,1.65),paint,.28)
box('Cab floor',(0,-4.4,3),(7.4,6.1,.7),paint)
box('Cab roof',(0,-4.25,6.9),(7.6,6.5,.35),paint,.18)
box('Windshield',(0,-7.25,5.3),(6.65,.13,2.45),glass,.05)
box('Back wall',(0,-1.15,4.7),(7.4,.25,3.9),paint)
box('Rear glass',(0,-1.31,5.65),(5.5,.08,1.6),glass)
for x in [-3.6,3.6]:
 for y in [-7.25,-1.2]:box('Window pillar',(x,y,5.3),(.25,.3,3),paint)
 box('Door',(x,-4.25,3.9),(.2,5.6,1.55),paint)
 box('Handle',(x*1.045,-2.5,4.5),(.17,.8,.15),chrome,.04)
 box('Mirror arm',(x*1.1,-6.4,4.9),(.7,.15,.15),chrome)
 box('Mirror',(x*1.21,-6.4,5.15),(.24,.9,.7),black)
 box('Side step',(x*1.13,-4.1,2.15),(.8,6.3,.2),chrome)
 box('Bed wall',(x*1.09,4.1,4),(.35,9.3,1.9),paint)
 box('Bed cap',(x*1.09,4.1,5),(.45,9.4,.15),black)
 for y in [-5.7,5.6]:
  cyl('Tire',(x*1.21,y,1.65),1.65,1.45,black);cyl('Rim',(x*1.42,y,1.65),1.08,.12,chrome);cyl('Hub',(x*1.45,y,1.65),.35,.16,black)
  for i in range(6):
   t=i*math.pi/3;cyl('Lug',(x*1.47,y+math.sin(t)*.52,1.65+math.cos(t)*.52),.095,.12,chrome)
  for i in range(16):
   t=i*math.pi/8;o=box('Tread',(x*1.21,y+math.sin(t)*1.6,1.65+math.cos(t)*1.6),(1.35,.25,.12),black,.02);o.rotation_euler.x=-t
box('Bed liner',(0,4.1,3.05),(7.7,9.3,.4),black)
for x in range(-3,4):box('Bed rib',(x,4.1,3.3),(.13,8.9,.08),chrome,.02)
box('Tailgate',(0,8.8,4),(7.9,.3,1.9),paint)
for y in [-9.65,9]:box('Bumper',(0,y,2.15),(8.1,.5,.55),chrome)
box('Grille',(0,-9.6,3.25),(4.8,.12,1),black)
for i in range(9):box('Grille slat',((i-4)*.5,-9.7,3.25),(.08,.1,.8),chrome,.02)
for x in [-2.9,2.9]:
 box('Headlamp',(x,-9.62,3.3),(1.2,.18,.85),white)
 box('Taillamp',(x,8.98,4),(.55,.12,.85),orange)
for x in [-1.75,1.75]:
 box('Seat cushion',(x,-4.2,4.05),(2.6,2.6,.55),black,.23);box('Seat back',(x,-2.95,4.9),(2.6,.5,2.2),black,.23)
box('Dashboard',(0,-6.45,4.6),(6.8,.8,.6),black)
bpy.ops.mesh.primitive_torus_add(major_segments=24,minor_segments=8,location=(-1.75,-5.6,4.95),rotation=(math.radians(65),0,0),major_radius=.65,minor_radius=.08);finish(bpy.context.object,'Steering wheel',black)
end('OldPickup',a)
a=begin();box('Sofa base',(0,0,0),(7.2,3.5,1.1),fabric,.22)
for x in [-3.3,3.3]:box('Arm',(x,0,.8),(.8,3.6,2),fabric,.26)
box('Back',(0,1.3,1.6),(7.2,.8,2.8),fabric,.2)
for x in [-2.2,0,2.2]:
 box('Seat cushion',(x,-.2,.8),(2.05,2.6,.55),fabric,.2);box('Back cushion',(x,.8,1.9),(2.05,.5,1.8),fabric,.2)
for x in [-2.9,2.9]:
 for y in [-1.1,1.1]:box('Foot',(x,y,-.8),(.3,.3,.6),black,.04)
end('Sofa',a)
a=begin();box('Cabinet',(0,0,0),(3.65,3.5,6.5),mint,.18)
for z,h in [(1.95,2.25),(-1.15,3.7)]:
 box('Door',(0,-1.82,z),(3.55,.2,h),white,.12);box('Handle',(1.25,-2.04,z),(.13,.2,h*.55),chrome,.06)
for i in range(7):box('Vent',(0,-1.88,-2.8+i*.08),(2.5,.04,.025),black,.005)
end('Fridge',a)
a=begin();ball('Body',(0,0,0),(3.6,3.35,2.6),yellow);ball('Head',(0,-1.05,3.25),(2.35,2.35,2.35),yellow);ball('Beak',(0,-3.2,2.9),(1.6,1,.42),orange)
for x in [-1.05,1.05]:ball('Eye',(x,-3.12,3.85),(.26,.16,.26),black);ball('Glint',(x-.07,-3.27,3.94),(.07,.04,.07),white)
for x in [-3.3,3.3]:ball('Wing',(x,.3,.25),(.65,2.05,1.35),yellow)
end('GiantDuck',a)
report={}
for name,objects in assets.items():
 bpy.ops.object.select_all(action='DESELECT')
 for o in objects:o.select_set(True)
 bpy.ops.export_scene.fbx(filepath=str(out/(name+'.fbx')),use_selection=True,axis_forward='-Z',axis_up='Y',add_leaf_bones=False,bake_anim=False)
 report[name]={'objects':len(objects),'triangles':sum(len(p.vertices)-2 for o in objects for p in o.data.polygons)}
# Display layout only after export: FBX stays in original gameplay coordinates.
for n,dx,dy in [('Sofa',13,-5),('Fridge',13,3),('GiantDuck',-13,2)]:
 for o in assets[n]:o.location.x+=dx;o.location.y+=dy
floor=box('Studio floor',(0,0,-1.5),(200,200,.3),mat('Backdrop',(.12,.15,.18)),0)
world=bpy.data.worlds.new('Studio world');bpy.context.scene.world=world;world.color=(.25,.25,.25)
for loc,power,size in [((5,-12,24),3500,12),((-15,-3,14),2200,10),((0,15,18),3000,8)]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.data.energy=power;o.data.shape='DISK';o.data.size=size;o.rotation_euler=(Vector((0,0,2))-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add(location=(32,-40,28));cam=bpy.context.object;cam.rotation_euler=(Vector((0,0,2))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=43
scene=bpy.context.scene;scene.camera=cam;scene.render.engine='CYCLES';scene.cycles.samples=24;scene.render.resolution_x=1400;scene.render.resolution_y=1000;scene.render.resolution_percentage=100;scene.render.filepath=str(out/'Blender-preview.png')
bpy.ops.wm.save_as_mainfile(filepath=str(out/'Dont-Drop-It-Models.blend'));bpy.ops.render.render(write_still=True)
(out/'mesh-report.json').write_text(json.dumps(report,indent=2))
